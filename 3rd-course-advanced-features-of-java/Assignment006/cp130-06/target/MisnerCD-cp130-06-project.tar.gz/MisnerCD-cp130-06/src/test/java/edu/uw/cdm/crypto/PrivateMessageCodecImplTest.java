package edu.uw.cdm.crypto;

import test.PrivateMessageCodecTest;

import static org.junit.jupiter.api.Assertions.*;

class PrivateMessageCodecImplTest extends PrivateMessageCodecTest {

}