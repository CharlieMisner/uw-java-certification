package edu.uw.rgm;

class MyBrokerTest extends test.BrokerTest {}
