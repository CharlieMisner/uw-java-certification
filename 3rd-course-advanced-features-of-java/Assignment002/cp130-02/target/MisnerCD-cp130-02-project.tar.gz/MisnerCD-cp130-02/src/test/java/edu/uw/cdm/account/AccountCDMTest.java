package edu.uw.cdm.account;

import test.AccountTest;

import static org.junit.jupiter.api.Assertions.*;

class AccountCDMTest extends AccountTest {

}