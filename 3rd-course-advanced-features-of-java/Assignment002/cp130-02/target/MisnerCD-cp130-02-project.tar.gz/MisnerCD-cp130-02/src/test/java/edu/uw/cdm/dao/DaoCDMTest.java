package edu.uw.cdm.dao;

import test.DaoTest;

class DaoCDMTest extends DaoTest {

}