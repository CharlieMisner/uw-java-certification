package edu.uw.cdm.broker;

import test.BrokerTest;

import static org.junit.jupiter.api.Assertions.*;

class BrokerCDMTest extends BrokerTest {

}