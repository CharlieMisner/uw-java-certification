package edu.uw.cdm.account;

import test.AccountManagerTest;

class AccountManagerCDMTest extends AccountManagerTest {

}