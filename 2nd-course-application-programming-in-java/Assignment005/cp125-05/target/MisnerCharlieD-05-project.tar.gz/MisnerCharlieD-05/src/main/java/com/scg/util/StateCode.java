package com.scg.util;

import java.io.Serializable;

public enum StateCode implements Serializable {
    WA("WASHINGTON"),
    CA("CALIFORINIA");

    StateCode(String description){}

}
