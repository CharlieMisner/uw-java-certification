package com.scg.util;

import static org.junit.jupiter.api.Assertions.*;

class AddressTest {

}