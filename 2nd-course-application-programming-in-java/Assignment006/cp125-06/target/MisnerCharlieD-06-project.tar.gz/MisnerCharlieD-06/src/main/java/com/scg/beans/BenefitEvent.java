package com.scg.beans;

import com.scg.domain.Consultant;

import javax.swing.text.html.Option;
import java.time.LocalDate;
import java.util.EventObject;
import java.util.Optional;

public class BenefitEvent extends EventObject {

    private Consultant consultant;
    private Optional<Boolean> dentalStatus;
    private Optional<Boolean> medicalStatus;
    private LocalDate effectiveDate;

    /**
     * Constructor
     * @param source
     * @param consultant
     * @param effectiveDate
     */
    public BenefitEvent(Object source, Consultant consultant, LocalDate effectiveDate, Optional<Boolean> dentalStatus, Optional<Boolean>medicalStatus){
        super(source);
        this.consultant = consultant;
        this.effectiveDate = effectiveDate;
        this.dentalStatus = dentalStatus;
        this.medicalStatus = medicalStatus;
    }

    /**
     * Cancels dental.
     * @param source
     * @param consultant
     * @param effectiveDate
     * @return
     */
    public static BenefitEvent cancelDental(Object source, Consultant consultant, LocalDate effectiveDate){
        BenefitEvent benefitEvent = new BenefitEvent(source, consultant, effectiveDate, Optional.of(false), Optional.empty());
        return benefitEvent;
    }

    /**
     * Cancels medical.
     * @param source
     * @param consultant
     * @param effectiveDate
     * @return
     */
    public static BenefitEvent cancelMedical(Object source, Consultant consultant, LocalDate effectiveDate){
        BenefitEvent benefitEvent = new BenefitEvent(source, consultant, effectiveDate, Optional.empty(),  Optional.of(false));
        return benefitEvent;
    }

    /**
     * Enrolls in dental.
     * @param source
     * @param consultant
     * @param effectiveDate
     * @return
     */
    public static BenefitEvent enrollDental(Object source, Consultant consultant, LocalDate effectiveDate){
        BenefitEvent benefitEvent = new BenefitEvent(source, consultant, effectiveDate, Optional.of(true), Optional.empty());
        return benefitEvent;
    }

    /**
     * Enrolls in medical.
     * @param source
     * @param consultant
     * @param effectiveDate
     * @return
     */
    public static BenefitEvent enrollMedical(Object source, Consultant consultant, LocalDate effectiveDate){
        BenefitEvent benefitEvent = new BenefitEvent(source, consultant, effectiveDate, Optional.empty(), Optional.of(true));
        return benefitEvent;
    }

    public Consultant getConsultant() {
        return consultant;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public Optional<Boolean> dentalStatus(){
        return this.dentalStatus;
    }

    public Optional<Boolean> medicalStatus(){
        return this.medicalStatus;
    }
}
