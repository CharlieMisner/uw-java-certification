package com.scg.util;

public enum StateCode {
    WA("WASHINGTON"),
    CA("CALIFORINIA");

    StateCode(String description){}

}
