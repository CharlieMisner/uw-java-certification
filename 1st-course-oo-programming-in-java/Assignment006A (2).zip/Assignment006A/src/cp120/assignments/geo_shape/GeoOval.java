package cp120.assignments.geo_shape;

public class GeoOval {
}
