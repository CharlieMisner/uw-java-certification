package cp120.assignments.geo_shape;

import java.util.ArrayList;
import java.util.List;

public class GeoPlane {

    List<GeoShape> shapes = new ArrayList<GeoShape>();

    public void addShape( GeoShape shape){}

    public void removeShape( GeoShape shape){}

    public List<GeoShape> getShapes(){
        return shapes;
    }

    public void redraw(){}
}
