package cp120.assignments.geo_shape;

import java.awt.Color;
import java.awt.Graphics2D;

public class GeoShape {

    private GeoPoint origin = new GeoPoint();
    private Color color;

    public GeoShape() {
        origin.setXco(0);
        origin.setYco(0);
    }

    public String toString() {
        int rgb = color.getRGB() & 0x00ffffff;
        String stringColor = String.format( "#%06x", rgb );
        return String.format("origin=(%.4f, %.4f),color=%s", this.origin.getXco(), this.origin.getYco(), stringColor);
    }

    // public abstract void draw(Graphics2D gtx);

    public GeoPoint getOrigin() {
        return origin;
    }

    public Color getColor() {
        return color;
    }

    public void setOrigin(GeoPoint origin) {
        try {
            if (origin == null){
                throw new IllegalArgumentException();
            } else {
                this.origin = origin;
            }
        } catch(IllegalArgumentException exception) {
            System.out.println("Origin cannot be null.");
        }
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
