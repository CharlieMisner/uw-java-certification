package cp120.assignments.geo_shape;
import java.lang.Math;

public class GeoPoint {

    private double xco;
    private double yco;

    public GeoPoint(){}

    public double distance (GeoPoint other){
        double xDifference = this.xco - other.xco;
        double yDifference = this.yco - other.yco;
        return Math.sqrt(Math.pow(xDifference, 2) + Math.pow(yDifference, 2));
    }

    public String toString(){
        return String.format("(%.4f, %.4f)", this.xco, this.yco);
    }

    public double getXco() {
        return xco;
    }

    public double getYco() {
        return yco;
    }

    public void setXco(double pointXCoordinate) {
        this.xco = pointXCoordinate;
    }

    public void setYco(double pointYCoordinate) {
        this.yco = pointYCoordinate;
    }
}
